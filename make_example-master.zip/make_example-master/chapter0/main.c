#include <stdio.h>

int main(void)
{
    printf("Hello Cacu!\n");
    return 0;
}
