#include "multi_div.h"

int multi(int a, int b)
{
	return a*b;
}

int div(int a, int b)
{
	return a/b;
}
