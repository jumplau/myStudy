#ifndef __MULTI_DIV_H__
#define __MULTI_DIV_H__

int multi(int a, int b); 
int div(int a, int b); 

#endif /*__MULTI_DIV_H__*/
