#include <stdio.h>

int foo(void)
{
	return 1;
}
