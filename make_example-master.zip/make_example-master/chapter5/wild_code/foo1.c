#include <stdio.h>
#include "foo1.h"

void foo1(void)
{
	printf("Hello foo1!\n");
}
