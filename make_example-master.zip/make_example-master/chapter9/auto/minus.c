#include <stdio.h>

int minus(int a,int b)
{
	return a-b;
}
